# Hotel-Room-Booking-System
It is A Hotel Room Booking Website developed using Django Framework, SQLite3, HTML, Bootstrap

<b>Users can:</b>
<ul>
  <li>Signup and Login</li>
  <li>Search for available places in hotels by date and location</li>
  <li>Reserve rooms</li>
  <li>See all reservation history in the "My Bookings"</li>
</ul>

<b>Managers can:</b>
<ul>
  <li>Login</li>
  <li>Search for availability of rooms in hotel by date and location</li>
  <li>Reserve rooms for customers (e.g. reserved by phone call) </li>
  <li>See the statistics of the rooms in the "Dashboard"</li>
  <li>See the bookings of all the users </li>
  <li>See/Modify the details of the rooms</li>
  <li>Add New Rooms</li>
  <li>Add New Location</li>
  <li>Filter bookings by: </ul>
	<li>* Check-in, check-out dates</li>
	<li>* Hotel locations</li>
	<li>* Guest name </li>


