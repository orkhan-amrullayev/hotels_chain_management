from django.apps import AppConfig


class MiltonConfig(AppConfig):
    name = 'milton'
