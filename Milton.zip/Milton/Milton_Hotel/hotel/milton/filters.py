import django_filters
from django_filters import DateFilter

from .models import *

class ReservationFilter(django_filters.FilterSet):
    class Meta:
        model = Reservation
        fields = '__all__'
